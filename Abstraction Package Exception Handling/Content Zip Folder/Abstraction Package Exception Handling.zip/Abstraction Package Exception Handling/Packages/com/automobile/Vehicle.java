package com.automobile;

abstract public class Vehicle 
{
	public abstract String getModelName();
	public abstract String getRegistrationNumber() ;
	public abstract String getOwnerName() ;
}
