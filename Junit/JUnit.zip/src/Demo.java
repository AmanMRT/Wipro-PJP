
public class Demo 
{
	String stringConcat(String a,String b)
	{
	String Concat=a+b;
	return Concat;
	}
}
