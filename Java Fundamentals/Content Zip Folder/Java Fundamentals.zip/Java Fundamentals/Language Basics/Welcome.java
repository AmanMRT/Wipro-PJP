//program to print WELCOME JOHN
public class Welcome
{
	//Driver Function
	public static void main(String[] args)
    {
	        String str="Welcome";
	        System.out.println(str + " " +args[0]);
    }//end	
}//end 