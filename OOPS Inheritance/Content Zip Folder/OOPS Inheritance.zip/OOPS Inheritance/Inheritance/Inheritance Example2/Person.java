
public class Person
{
	String name;
	public void setName(String newName)
	{
		name= newName;
	}
	public String getName()
	{
		return name;
	}
}
